print('--------gunakan modul-----------')
import hitung
hitung.tambah(5,2)
hitung.kurang(10,3)
hitung.kali(5,6)

print('\n--gunakan modul yg ada dgn alias--')
import hitung as ht
ht.bagi(20,2)
ht.pangkat(2,3)

